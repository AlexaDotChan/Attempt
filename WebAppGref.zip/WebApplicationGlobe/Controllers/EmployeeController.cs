﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using WebApplicationGlobe.Models;


namespace WebApplicationGlobe.Controllers
{
    public class EmployeeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult ReadEmployees()
        {
            return View(DAOEmployee.GetInstance().ReadEmployees());
        }//localhost/Employee/ReadEmployees

        public IActionResult SearchEmployee(int id)
        {
            Employee ris = DAOEmployee.GetInstance().SearchEmployee(id);

            if (ris != null)
                return View(ris);
            else
                return View("EmployeeNOTFound.html");
        }//localhost/Employee/SearchEmployee/1
         //localhost/Employee/SearchEmployee?id=1

        public IActionResult NewEmployeeForm()
        {
            return View();
        } //This acton will alow the customet that is viewing my website to apply for a position
          //so I have then to create a form in JS to insert data

        public IActionResult NewEmployee(Dictionary<string, string> parameters)
        {
            //I need to create a new Employee through the parameters that I will receive
            Employee d = new Employee();
            d.FromDictionary(parameters);

            //I need to make a call to DAOEmployee for the new one
            DAOEmployee.GetInstance().Save(d);

            //To redirect the new Employee to the list of Employees
            return Redirect("/Employee/ReadEmployee");
        }

        //To delete an Employee in the list
        public IActionResult Delete(int id)
        {
            if (DAOEmployee.GetInstance().Delete(id))
                return Redirect("/Employee/ReadEmployees");
            else
                return Content("Sorry, there was an error in the cancellation");
        }
        public IActionResult FormModifyEmployee(int id)
        {
            Employee toModify = DAOEmployee.GetInstance().SearchEmployee(id);

            return View(toModify); 
        }

        public IActionResult ModifyEmployee(Dictionary<string, string> parameters)
        {
            Employee toModify = new Employee();
            toModify.FromDictionary(parameters);

            if (DAOEmployee.GetInstance().Modify(toModify))
                return Redirect("/Employee/ReadEmployee");
            else
                return Content("Sorry, there was an error, please check your submission.");
        }
    }
}
