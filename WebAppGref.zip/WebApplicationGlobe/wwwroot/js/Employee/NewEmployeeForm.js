﻿function validateForm()
{
    //I am setting some checks

    //for the name 
    if (document.getElementById("name").value.length < 3)
    {
        alert("Please type a name of at least 3 letters)");
        return false;
    }

    //for the surname
    if (document.getElementById("surname").value.length < 3)
    {
        alert("Please type a surname of at least 3 letters)");
        return false;
    }

    //for the department that can be selected
    switch (document.getElementById("reparto").value.toLowerCase())
    {
        case "purchase":
        case "sales":
        case "secretariat":
        case "administration":
            break;
        default:
            alert("Please insert only the correct departments: Purchase, Sales, Secretariat, Administration");
            return false;
    }

    //for the residence 
    if (document.getElementById("residence").value.length < 4)
    {
        alert("The residence should contain at least 4 letters");
        return false;
    }

    //the dob should be legal... so I calculated current year -17 to ensure the employee has the legal age to work
    var annoInserito = parseInt(document.getElementById("dob").value.split("-")[0]);
    var annoCorrente = new Date().getFullYear();

    if (annoCorrente - 17 <= annoInserito)
    {
        alert("You are legally not allowed to work for us. Sorry");
        return false;
    }

    return true;
}

//some more eventual checks
var departments = ["Purchase", "Sales", "Secretariat", "Administration"];

var ris = "";

for (var i = 0; i < departments.length; i++)
    ris += "<option value='" + departments[i] + "'>" + departments[i] + "</option>";

document.getElementById("department").innerHTML = ris;



    var employeeExample = new XMLHttpRequest();

    employeeExample.onload = function ()
    {
        var residenze = JSON.parse(this.responseText);

