﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Utility;

namespace WebApplicationGlobe.Models
{
    public class DAOEmployee
    {
        private Database db;

        private static DAOEmployee instance;
        //I'll do the db in my SQL workbench and connect it here later
        private DAOEmployee()
        {
            db = new Database("TheGlobe", "192.168.0.168", "root", "rooot");
        }

        public static DAOEmployee GetInstance()
        {
            if (instance == null)
                instance = new DAOEmployee();
            return instance;
        }

        public List<Employee> ReadEmployees() //better to not use ListEmployees
        {
            List<Employee> ris = new List<Employee>();

            string query = "select * from employees";
            List<Dictionary<string, string>> righe = db.Read(query);

            foreach (Dictionary<string, string> riga in righe)
            {
                Employee d = new Employee();
                d.FromDictionary(riga);
                ris.Add(d);
            }

            return ris;
        }

        public Employee SearchEmployee(int id)
        {
            Employee d = null;

            foreach (Employee dip in ReadEmployees())
                if (dip.Id == id)
                    d = dip;

            return d;
        }

        public bool Delete(int id)
        {
            string query = "delete from employees where id = " + id;

            return db.Update(query);
        }

        public bool Save(Employee d)
        {
            string query = "insert into employees " +
                           "(name, surname, residence, deprtment, dob) values " +
                          $"('{d.Name}', '{d.Surname}', '{d.Residence}', " +
                          $"'{d.Department}', '{d.Dob.Year}-{d.Dob.Month}-{d.Dob.Day}')";

            return db.Update(query);
        }

        public bool Modify(Employee d)
        {
            string query = $"update employees set name = '{d.Name}', surname = '{d.Surname}', " +
                           $"residence = '{d.Residence}', department = '{d.Department}', " +
                           $"dob = '{d.Dob:yyyy-MM-dd}' where id = {d.Id}";

            return db.Update(query);
        }
    }
}
