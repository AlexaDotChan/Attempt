﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Utility;
//I do have my own Utility created during the course so I add it as a project reference (!)

namespace WebApplicationGlobe.Models
{
    public class Employee : Entity //Employee e' figlia di entity
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public DateTime Dob { get; set; }
        public string Department { get; set; }
        public string Residence { get; set; }

        public Employee(int id, string name, string surname, DateTime dob,
                          string department, string residence)
        : base(id)
        {
            Name = name;
            Surname = surname;
            Dob = dob;
            Department = department;
            Residence = residence;
        }

        public Employee() { }
    }
}
