using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplicationGlobe
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });

        //MY STEPS
        // 1) add my project reference
        // 2) start with the folder Models : creating the properties of Employee
        // 3) I create the DAOEmployee class :  // I choose to use the singleton pattern to ensure all the Employees have the same characteristics
        // 4) I implement the CRUD methods 
        // 5) I change the HomeController with simple commands for the View returned
        // 6) I create the EmployeeController in the Controllers folder
        // 7) I implement all the methods and form for a new Employee and form to delete and modify an existing one
        // 8) I create in JS the form to fill for a newEmployee considering some checks
        // 9) I create a new folder PAGES to put the layout of my page
        // 10) Because I changed the Layout I need to check also in the Shared folder if  I need to rename the Layer
        // 11) I import the style I noted on code and create the cshtml folder with also connections and functions in js
        // 12) I made a form for a NewEmployee, one for SearchEmployee and one for ReadEmployee(the list)
        // 13) the form for a new employee is connected with the NewEmployeeForm.js to have all the checks done
        // 13) After checking the pages connected I set my navbat to recall the pages needed 
        //              href="~/cshtml/Employee.cshtml"
        //              href="~/cshtml/ReadEmployees.cshtml"
        //              href="~/cshtml/SearchEmployee.cshtml"
        //              href="#NewEmployeeForm.js"
        // 14) Checked for the common link rel.



    }
}
