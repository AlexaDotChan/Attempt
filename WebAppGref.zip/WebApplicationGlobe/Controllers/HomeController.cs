﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using WebApplicationGlobe.Models;

namespace WebApplicationGlobe.Controllers
{
    public class HomeController : Controller
    {
        //I change the HomeComtroller with some basics just to redirect it easily
        public IActionResult Index()
        {
            return View("Views/Home/Index.cshtml");
        }//localhost/Home

        public string About()
        {
            return "Pagina con le nostre informazioni riguardo TheGlobe";
        }//localhost/Home/About
        
    }
}
